/*
 * Vueko - Terminal Web Browser
 * browser.c — UI ncurses principale
 *
 * Layout:
 *  [0]   TOP BAR     : titre + raccourcis
 *  [1]   ADDR BAR    : URL courante
 *  [2..H-2] CONTENT  : résultats / page rendue
 *  [H-1] STATUS BAR  : infos / pagination
 *
 * Raccourcis:
 *   Ctrl+R  : nouvelle recherche
 *   Entrée  : ouvrir le résultat sélectionné
 *   Tab     : basculer entre mode résultats / liens de la page
 *   ↑/↓     : navigation
 *   PgUp/Dn : défilement rapide
 *   B       : retour à la liste des résultats
 *   Q/ESC   : quitter
 */

#include <ncurses.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <json-c/json.h>
#include <unistd.h>
#include <sys/wait.h>
#include <ctype.h>

/* ─── Couleurs ───────────────────────────────────────────────────── */
#define CP_TOPBAR       1   /* fond bleu marine  */
#define CP_STATUSBAR    2   /* fond vert foncé   */
#define CP_ADDRBAR      3   /* fond gris foncé   */
#define CP_HIGHLIGHT    4   /* sélection cyan    */
#define CP_TITLE        5   /* titres résultats  */
#define CP_URL          6   /* URL gris          */
#define CP_SPINNER      7   /* animation         */
#define CP_LINK_HL      8   /* lien sélectionné  */
#define CP_HEADING      9   /* titres page HTML  */
#define CP_NORMAL      10   /* texte normal      */
#define CP_VIDEO       11   /* badge vidéo       */
#define CP_SEPARATOR   12   /* séparateurs       */

/* ─── Constantes ─────────────────────────────────────────────────── */
#define MAX_RESULTS     1000
#define MAX_LINKS       2000
#define MAX_LEN         2048
#define PAGE_JUMP       10

/* ─── Structures ─────────────────────────────────────────────────── */
typedef struct {
    char title[MAX_LEN];
    char url[MAX_LEN];
    char site[256];
} Result;

typedef struct {
    char text[MAX_LEN];
    char url[MAX_LEN];
} PageLink;

typedef enum {
    MODE_SEARCH,   /* liste de résultats Bing */
    MODE_PAGE      /* page rendue (render.py) */
} AppMode;

/* ─── Globals ────────────────────────────────────────────────────── */
Result    results[MAX_RESULTS];
int       results_count  = 0;
int       results_scroll = 0;
int       results_hl     = 0;

PageLink  page_links[MAX_LINKS];
int       page_links_count = 0;

/* Lignes de la page rendue (JSON -> tableau de texte) */
#define MAX_PAGE_LINES  8000
char      page_lines[MAX_PAGE_LINES][MAX_LEN];
int       page_lines_count = 0;
int       page_scroll      = 0;
int       page_links_hl    = 0;      /* lien surligné dans la page */
int       link_positions[MAX_LINKS]; /* ligne où apparaît chaque lien */

char      current_url[MAX_LEN] = "";
char      current_title[MAX_LEN] = "Vueko";
AppMode   mode = MODE_SEARCH;
int       links_panel_open = 0;      /* panneau liens latéral */

/* ─── Helpers ────────────────────────────────────────────────────── */
static void run_spinner(WINDOW *win, const char *msg, pid_t pid) {
    char spinner[] = {'⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏'};
    /* fallback ASCII si terminal basique */
    char spin_ascii[] = {'|','/','-','\\'};
    int  step   = 0;
    int  status;
    int  height, width;
    getmaxyx(stdscr, height, width);

    while (waitpid(pid, &status, WNOHANG) == 0) {
        int  box_w  = (int)strlen(msg) + 8;
        if (box_w > width - 4) box_w = width - 4;
        int  box_x  = (width  - box_w) / 2;
        int  box_y  = (height - 3)     / 2;

        WINDOW *sw = newwin(3, box_w, box_y, box_x);
        wbkgd(sw, COLOR_PAIR(CP_SPINNER));
        box(sw, 0, 0);
        wattron(sw, COLOR_PAIR(CP_SPINNER) | A_BOLD);
        mvwprintw(sw, 1, 2, "%c  %.*s", spin_ascii[step % 4],
                  box_w - 6, msg);
        wattroff(sw, A_BOLD);
        wrefresh(sw);
        delwin(sw);

        usleep(80000);
        step++;
    }
}

static void fill_bar(WINDOW *w, int pair, const char *left,
                     const char *center, const char *right) {
    int h, width;
    getmaxyx(w, h, width);
    (void)h;
    wbkgd(w, COLOR_PAIR(pair));
    werase(w);
    wattron(w, COLOR_PAIR(pair) | A_BOLD);
    mvwprintw(w, 0, 1, "%s", left);
    if (center && *center) {
        int cx = (width - (int)strlen(center)) / 2;
        if (cx < 1) cx = 1;
        mvwprintw(w, 0, cx, "%s", center);
    }
    if (right && *right) {
        int rx = width - (int)strlen(right) - 2;
        if (rx > 0) mvwprintw(w, 0, rx, "%s", right);
    }
    wattroff(w, A_BOLD);
    wrefresh(w);
}

/* ─── Chargement JSON résultats ──────────────────────────────────── */
static void load_search_results(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) { results_count = 0; return; }

    fseek(fp, 0, SEEK_END);
    long sz = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char *buf = malloc(sz + 1);
    fread(buf, 1, sz, fp);
    buf[sz] = 0;
    fclose(fp);

    struct json_object *arr = json_tokener_parse(buf);
    free(buf);
    if (!arr || json_object_get_type(arr) != json_type_array) {
        results_count = 0;
        return;
    }

    int len = json_object_array_length(arr);
    results_count = len > MAX_RESULTS ? MAX_RESULTS : len;

    for (int i = 0; i < results_count; i++) {
        struct json_object *item  = json_object_array_get_idx(arr, i);
        struct json_object *title, *url, *site;
        json_object_object_get_ex(item, "title", &title);
        json_object_object_get_ex(item, "url",   &url);
        json_object_object_get_ex(item, "site",  &site);

#define COPY_FIELD(dst, src) \
        if (src && json_object_get_type(src) == json_type_string) \
            snprintf(dst, sizeof(dst), "%s", json_object_get_string(src)); \
        else dst[0] = '\0';

        COPY_FIELD(results[i].title, title)
        COPY_FIELD(results[i].url,   url)
        COPY_FIELD(results[i].site,  site)
    }
    json_object_put(arr);
}

/* ─── Chargement page rendue (render.py → JSON) ──────────────────── */
static void load_rendered_page(const char *filename) {
    page_lines_count = 0;
    page_links_count = 0;
    page_scroll      = 0;
    page_links_hl    = 0;

    FILE *fp = fopen(filename, "r");
    if (!fp) {
        snprintf(page_lines[0], MAX_LEN, "  [Erreur: impossible d'ouvrir %s]", filename);
        page_lines_count = 1;
        return;
    }

    fseek(fp, 0, SEEK_END);
    long sz = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char *buf = malloc(sz + 1);
    fread(buf, 1, sz, fp);
    buf[sz] = 0;
    fclose(fp);

    struct json_object *root = json_tokener_parse(buf);
    free(buf);
    if (!root) {
        snprintf(page_lines[0], MAX_LEN, "  [Erreur JSON dans %s]", filename);
        page_lines_count = 1;
        return;
    }

    /* root = { "lines": [...], "links": [...] } */
    struct json_object *jlines, *jlinks;
    json_object_object_get_ex(root, "lines", &jlines);
    json_object_object_get_ex(root, "links", &jlinks);

    if (jlines && json_object_get_type(jlines) == json_type_array) {
        int n = json_object_array_length(jlines);
        if (n > MAX_PAGE_LINES) n = MAX_PAGE_LINES;
        for (int i = 0; i < n; i++) {
            struct json_object *l = json_object_array_get_idx(jlines, i);
            snprintf(page_lines[i], MAX_LEN, "%s",
                     json_object_get_string(l));
        }
        page_lines_count = n;
    }

    if (jlinks && json_object_get_type(jlinks) == json_type_array) {
        int n = json_object_array_length(jlinks);
        if (n > MAX_LINKS) n = MAX_LINKS;
        for (int i = 0; i < n; i++) {
            struct json_object *item = json_object_array_get_idx(jlinks, i);
            struct json_object *text, *url, *line;
            json_object_object_get_ex(item, "text", &text);
            json_object_object_get_ex(item, "url",  &url);
            json_object_object_get_ex(item, "line", &line);
            COPY_FIELD(page_links[i].text, text)
            COPY_FIELD(page_links[i].url,  url)
            link_positions[i] = line ? json_object_get_int(line) : 0;
        }
        page_links_count = n;
    }

    json_object_put(root);
}

/* ─── Saisie utilisateur (popup) ─────────────────────────────────── */
static void popup_input(const char *label, char *out, int size) {
    int height, width;
    getmaxyx(stdscr, height, width);

    int bw = width * 2 / 3;
    int bx = (width - bw) / 2;
    int by = height / 2 - 2;

    WINDOW *pw = newwin(5, bw, by, bx);
    wbkgd(pw, COLOR_PAIR(CP_ADDRBAR));
    box(pw, 0, 0);
    wattron(pw, COLOR_PAIR(CP_ADDRBAR) | A_BOLD);
    mvwprintw(pw, 0, 2, " %s ", label);
    wattroff(pw, A_BOLD);
    mvwprintw(pw, 2, 2, "> ");
    wrefresh(pw);

    echo();
    curs_set(1);
    wmove(pw, 2, 4);
    wgetnstr(pw, out, size - 1);
    curs_set(0);
    noecho();
    delwin(pw);
}

/* ─── Dessin : liste résultats ───────────────────────────────────── */
static void draw_results(WINDOW *win) {
    int height, width;
    getmaxyx(win, height, width);
    werase(win);
    wbkgd(win, COLOR_PAIR(CP_NORMAL));

    if (results_count == 0) {
        wattron(win, COLOR_PAIR(CP_URL) | A_DIM);
        mvwprintw(win, height / 2, (width - 32) / 2,
                  "Aucun résultat — Ctrl+R pour rechercher");
        wattroff(win, A_DIM);
        wrefresh(win);
        return;
    }

    for (int i = 0; i < height - 1; i++) {
        int idx = results_scroll + i;
        if (idx >= results_count) break;

        int is_hl = (idx == results_hl);
        int row   = i;

        /* Fond de la ligne surlignée */
        if (is_hl) {
            wattron(win, COLOR_PAIR(CP_HIGHLIGHT) | A_BOLD);
            for (int c = 0; c < width - 1; c++)
                mvwaddch(win, row, c, ' ');
        }

        /* Numéro */
        if (!is_hl) wattron(win, COLOR_PAIR(CP_URL) | A_DIM);
        mvwprintw(win, row, 1, "%2d", idx + 1);
        if (!is_hl) wattroff(win, A_DIM);

        /* Titre */
        int max_title = width - 6 - (int)strlen(results[idx].site) - 3;
        if (max_title < 4) max_title = 4;
        if (!is_hl) wattron(win, COLOR_PAIR(CP_TITLE) | A_BOLD);
        mvwprintw(win, row, 4, "%.*s", max_title, results[idx].title);
        if (!is_hl) wattroff(win, A_BOLD);

        /* Site (à droite) */
        if (results[idx].site[0]) {
            if (!is_hl) wattron(win, COLOR_PAIR(CP_URL) | A_DIM);
            mvwprintw(win, row, width - (int)strlen(results[idx].site) - 2,
                      "%s", results[idx].site);
            if (!is_hl) wattroff(win, A_DIM);
        }

        if (is_hl) wattroff(win, COLOR_PAIR(CP_HIGHLIGHT) | A_BOLD);
    }

    /* Scrollbar */
    if (results_count > height - 1) {
        int sb_h   = height - 1;
        int th     = (sb_h * (height - 1)) / results_count;
        if (th < 1) th = 1;
        int tp = (results_scroll * (sb_h - th)) / (results_count - (height - 1));
        if (tp > sb_h - th) tp = sb_h - th;

        wattron(win, COLOR_PAIR(CP_SEPARATOR));
        for (int i = 0; i < sb_h; i++)
            mvwaddch(win, i, width - 1, ACS_VLINE);
        for (int i = 0; i < th; i++)
            mvwaddch(win, tp + i, width - 1, ACS_BLOCK);
        wattroff(win, COLOR_PAIR(CP_SEPARATOR));
    }

    wrefresh(win);
}

/* ─── Dessin : page rendue ───────────────────────────────────────── */
static void draw_page(WINDOW *win) {
    int height, width;
    getmaxyx(win, height, width);
    werase(win);
    wbkgd(win, COLOR_PAIR(CP_NORMAL));

    if (page_lines_count == 0) {
        wattron(win, COLOR_PAIR(CP_URL) | A_DIM);
        mvwprintw(win, height / 2, (width - 24) / 2, "Page vide ou non chargée");
        wattroff(win, A_DIM);
        wrefresh(win);
        return;
    }

    /* Construire un index : quelle ligne du contenu correspond à quel lien hl */
    int next_link_line = -1;
    if (page_links_count > 0 && page_links_hl < page_links_count)
        next_link_line = link_positions[page_links_hl];

    for (int i = 0; i < height; i++) {
        int li = page_scroll + i;
        if (li >= page_lines_count) break;

        char *line = page_lines[li];

        /* Détecte le type de ligne via préfixe de contrôle */
        int attr = COLOR_PAIR(CP_NORMAL);
        int prefix_len = 0;

        if (strncmp(line, "##H1 ", 5) == 0) {
            attr = COLOR_PAIR(CP_HEADING) | A_BOLD | A_UNDERLINE;
            prefix_len = 5;
        } else if (strncmp(line, "##H2 ", 5) == 0) {
            attr = COLOR_PAIR(CP_HEADING) | A_BOLD;
            prefix_len = 5;
        } else if (strncmp(line, "##H3 ", 5) == 0) {
            attr = COLOR_PAIR(CP_HEADING) | A_BOLD;
            prefix_len = 5;
        } else if (strncmp(line, "##LK ", 5) == 0) {
            /* Ligne de lien — chercher si c'est le lien sélectionné */
            int is_link_hl = (li == next_link_line);
            attr = is_link_hl ? (COLOR_PAIR(CP_LINK_HL) | A_BOLD)
                              : (COLOR_PAIR(CP_URL)     | A_UNDERLINE);
            prefix_len = 5;
        } else if (strncmp(line, "##VD ", 5) == 0) {
            attr = COLOR_PAIR(CP_VIDEO) | A_BOLD;
            prefix_len = 5;
        } else if (strncmp(line, "##HR", 4) == 0) {
            wattron(win, COLOR_PAIR(CP_SEPARATOR) | A_DIM);
            for (int c = 0; c < width - 1; c++)
                mvwaddch(win, i, c, ACS_HLINE);
            wattroff(win, A_DIM);
            continue;
        }

        wattron(win, attr);
        mvwprintw(win, i, 0, "%.*s", width - 1, line + prefix_len);
        wattroff(win, attr);
    }

    /* Scrollbar */
    if (page_lines_count > height) {
        int sb_h = height;
        int th   = (sb_h * height) / page_lines_count;
        if (th < 1) th = 1;
        int tp = (page_scroll * (sb_h - th)) / (page_lines_count - height);
        if (tp > sb_h - th) tp = sb_h - th;
        wattron(win, COLOR_PAIR(CP_SEPARATOR));
        for (int i = 0; i < sb_h; i++)
            mvwaddch(win, i, width - 1, ACS_VLINE);
        for (int i = 0; i < th; i++)
            mvwaddch(win, tp + i, width - 1, ACS_BLOCK);
        wattroff(win, COLOR_PAIR(CP_SEPARATOR));
    }

    wrefresh(win);
}

/* ─── Panneau latéral des liens ──────────────────────────────────── */
static void draw_links_panel(int x, int y, int h, int w) {
    WINDOW *lw = newwin(h, w, y, x);
    wbkgd(lw, COLOR_PAIR(CP_ADDRBAR));
    box(lw, 0, 0);
    wattron(lw, COLOR_PAIR(CP_ADDRBAR) | A_BOLD);
    mvwprintw(lw, 0, 2, " Liens (%d) ", page_links_count);
    wattroff(lw, A_BOLD);

    int visible = h - 2;
    int start   = page_links_hl > visible ? page_links_hl - visible / 2 : 0;

    for (int i = 0; i < visible; i++) {
        int idx = start + i;
        if (idx >= page_links_count) break;
        int is_hl = (idx == page_links_hl);
        if (is_hl)
            wattron(lw, COLOR_PAIR(CP_HIGHLIGHT) | A_BOLD);
        else
            wattron(lw, COLOR_PAIR(CP_URL));

        mvwprintw(lw, i + 1, 1, "%.*s", w - 3, page_links[idx].text);

        if (is_hl)  wattroff(lw, COLOR_PAIR(CP_HIGHLIGHT) | A_BOLD);
        else        wattroff(lw, COLOR_PAIR(CP_URL));
    }
    wrefresh(lw);
    delwin(lw);
}

/* ─── Lecture vidéo (convert + play) ────────────────────────────── */
static void play_video(const char *mp4_path, WINDOW *content_win) {
    /* 1. convert */
    char cmd_conv[MAX_LEN];
    snprintf(cmd_conv, sizeof(cmd_conv), "./convert \"%s\"", mp4_path);

    wclear(content_win); wrefresh(content_win);
    char msg[512];
    snprintf(msg, sizeof(msg), "Conversion vidéo...");

    pid_t pid = fork();
    if (pid == 0) { system(cmd_conv); exit(0); }
    if (pid > 0)  run_spinner(content_win, msg, pid);

    /* Chemins gif/mp3 */
    char gif[MAX_LEN], mp3[MAX_LEN];
    snprintf(gif, sizeof(gif), "%s", mp4_path);
    snprintf(mp3, sizeof(mp3), "%s", mp4_path);
    /* Remplace .mp4 par .gif / .mp3 */
    char *dot_gif = strrchr(gif, '.');
    char *dot_mp3 = strrchr(mp3, '.');
    if (dot_gif) strcpy(dot_gif, ".gif");
    if (dot_mp3) strcpy(dot_mp3, ".mp3");

    /* 2. play (plein écran — quitte ncurses temporairement) */
    endwin();
    char cmd_play[MAX_LEN * 2];
    snprintf(cmd_play, sizeof(cmd_play), "./play \"%s\" \"%s\"", gif, mp3);
    system(cmd_play);
    /* Réinitialise ncurses */
    refresh();
    wrefresh(content_win);
}

/* ─── Ouverture d'une page ───────────────────────────────────────── */
static void open_url(const char *url, const char *title, WINDOW *content_win) {
    /* Cas spécial : lien vidéo interne */
    if (strncmp(url, "file://__video__", 16) == 0) {
        play_video(url + 16, content_win);
        return;
    }

    snprintf(current_url,   sizeof(current_url),   "%s", url);
    snprintf(current_title, sizeof(current_title), "%s", title ? title : url);

    char cmd[MAX_LEN * 2];
    snprintf(cmd, sizeof(cmd), "python3 GET.py \"%s\"", url);

    pid_t pid = fork();
    if (pid == 0) { system(cmd); exit(0); }

    if (pid > 0) {
        wclear(content_win); wrefresh(content_win);
        char msg[512];
        snprintf(msg, sizeof(msg), "Chargement: %.60s", title ? title : url);
        run_spinner(content_win, msg, pid);
    }

    /* Render HTML → JSON */
    char cmd_render[256];
    snprintf(cmd_render, sizeof(cmd_render), "python3 render.py");
    pid = fork();
    if (pid == 0) { system(cmd_render); exit(0); }
    if (pid > 0) {
        int st; waitpid(pid, &st, 0);
    }

    load_rendered_page("datas/cache/page.json");
    mode = MODE_PAGE;
}

/* ─── Main ───────────────────────────────────────────────────────── */
int main(void) {
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);
    start_color();
    use_default_colors();

    /* Palette */
    init_pair(CP_TOPBAR,    COLOR_WHITE,   COLOR_BLUE);
    init_pair(CP_STATUSBAR, COLOR_WHITE,   COLOR_GREEN);
    init_pair(CP_ADDRBAR,   COLOR_WHITE,   238 /* gris foncé, fallback: COLOR_BLACK */);
    init_pair(CP_HIGHLIGHT, COLOR_BLACK,   COLOR_CYAN);
    init_pair(CP_TITLE,     COLOR_WHITE,   -1);
    init_pair(CP_URL,       COLOR_CYAN,    -1);
    init_pair(CP_SPINNER,   COLOR_BLACK,   COLOR_YELLOW);
    init_pair(CP_LINK_HL,   COLOR_BLACK,   COLOR_CYAN);
    init_pair(CP_HEADING,   COLOR_YELLOW,  -1);
    init_pair(CP_NORMAL,    -1,            -1);
    init_pair(CP_VIDEO,     COLOR_BLACK,   COLOR_MAGENTA);
    init_pair(CP_SEPARATOR, COLOR_WHITE,   -1);

    /* Fallback si terminal 8 couleurs */
    if (!can_change_color())
        init_pair(CP_ADDRBAR, COLOR_WHITE, COLOR_BLACK);

    int height, width;
    getmaxyx(stdscr, height, width);

    /* Fenêtres */
    WINDOW *top_win    = newwin(1, width, 0, 0);
    WINDOW *addr_win   = newwin(1, width, 1, 0);
    WINDOW *content_win = newwin(height - 3, width, 2, 0);
    WINDOW *status_win = newwin(1, width, height - 1, 0);

    /* Chargement initial */
    load_search_results("datas/cache/search_results.json");

    int ch;
    char query[512] = "";

    while (1) {
        /* ── Recalcul dimensions si resize ── */
        getmaxyx(stdscr, height, width);
        wresize(top_win,     1,          width);
        wresize(addr_win,    1,          width);
        wresize(content_win, height - 3, width);
        wresize(status_win,  1,          width);
        mvwin(status_win, height - 1, 0);

        int content_h = height - 3;

        /* ── Top bar ── */
        fill_bar(top_win, CP_TOPBAR,
                 " 🌐 Vueko",
                 mode == MODE_SEARCH ? "[ Résultats ]" : current_title,
                 "^R:Recherche  B:Retour  Tab:Liens  Q:Quitter ");

        /* ── Addr bar ── */
        {
            werase(addr_win);
            wbkgd(addr_win, COLOR_PAIR(CP_ADDRBAR));
            wattron(addr_win, COLOR_PAIR(CP_ADDRBAR));
            mvwprintw(addr_win, 0, 1, " %.*s",
                      width - 4,
                      current_url[0] ? current_url : "about:blank");
            wattroff(addr_win, COLOR_PAIR(CP_ADDRBAR));
            wrefresh(addr_win);
        }

        /* ── Content ── */
        if (mode == MODE_SEARCH) {
            /* Scroll guard */
            if (results_hl < results_scroll)
                results_scroll = results_hl;
            if (results_hl >= results_scroll + content_h)
                results_scroll = results_hl - content_h + 1;
            draw_results(content_win);
        } else {
            /* Scroll guard page */
            if (page_scroll < 0) page_scroll = 0;
            int max_scroll = page_lines_count - content_h;
            if (max_scroll < 0) max_scroll = 0;
            if (page_scroll > max_scroll) page_scroll = max_scroll;
            draw_page(content_win);

            /* Panneau liens */
            if (links_panel_open && page_links_count > 0) {
                int pw = width / 3;
                if (pw < 20) pw = 20;
                draw_links_panel(width - pw, 2, content_h, pw);
            }
        }

        /* ── Status bar ── */
        {
            char left[256], right[256];
            if (mode == MODE_SEARCH) {
                snprintf(left,  sizeof(left),  " %d résultat(s)",
                         results_count);
                snprintf(right, sizeof(right), " [%d/%d] ",
                         results_count ? results_hl + 1 : 0, results_count);
            } else {
                snprintf(left,  sizeof(left),  " %d ligne(s)  %d lien(s)",
                         page_lines_count, page_links_count);
                int pct = page_lines_count > 0
                          ? (page_scroll * 100) / page_lines_count : 0;
                snprintf(right, sizeof(right), " %d%% ", pct);
            }
            fill_bar(status_win, CP_STATUSBAR, left, NULL, right);
        }

        /* ── Input ── */
        ch = getch();

        /* Quitter */
        if (ch == 'q' || ch == 'Q' || ch == 27) break;

        /* Ctrl+R : nouvelle recherche */
        if (ch == 18) {
            popup_input("Recherche", query, sizeof(query));
            if (query[0] == '\0') continue;

            char cmd[1024];
            snprintf(cmd, sizeof(cmd), "python3 search.py '%s'", query);

            pid_t pid = fork();
            if (pid == 0) { system(cmd); exit(0); }
            if (pid > 0) {
                wclear(content_win); wrefresh(content_win);
                char msg[512];
                snprintf(msg, sizeof(msg), "Recherche: %.80s", query);
                run_spinner(content_win, msg, pid);
            }

            load_search_results("datas/cache/search_results.json");
            snprintf(current_url, sizeof(current_url),
                     "bing://search?q=%s", query);
            results_hl     = 0;
            results_scroll = 0;
            mode           = MODE_SEARCH;
            links_panel_open = 0;
        }

        /* B : retour aux résultats */
        else if ((ch == 'b' || ch == 'B') && mode == MODE_PAGE) {
            mode = MODE_PAGE;  /* on reste — ou revenir ? */
            mode = MODE_SEARCH;
            links_panel_open = 0;
        }

        /* Tab : ouvrir/fermer panneau liens */
        else if (ch == '\t' && mode == MODE_PAGE) {
            links_panel_open = !links_panel_open;
        }

        /* Navigation ↑ */
        else if (ch == KEY_UP) {
            if (mode == MODE_SEARCH) {
                if (results_hl > 0) results_hl--;
            } else {
                if (links_panel_open) {
                    if (page_links_hl > 0) {
                        page_links_hl--;
                        page_scroll = link_positions[page_links_hl];
                    }
                } else {
                    if (page_scroll > 0) page_scroll--;
                }
            }
        }

        /* Navigation ↓ */
        else if (ch == KEY_DOWN) {
            if (mode == MODE_SEARCH) {
                if (results_hl < results_count - 1) results_hl++;
            } else {
                if (links_panel_open) {
                    if (page_links_hl < page_links_count - 1) {
                        page_links_hl++;
                        page_scroll = link_positions[page_links_hl];
                    }
                } else {
                    if (page_scroll < page_lines_count - content_h)
                        page_scroll++;
                }
            }
        }

        /* PgUp */
        else if (ch == KEY_PPAGE) {
            if (mode == MODE_SEARCH) {
                results_hl -= PAGE_JUMP;
                if (results_hl < 0) results_hl = 0;
            } else {
                page_scroll -= PAGE_JUMP;
                if (page_scroll < 0) page_scroll = 0;
            }
        }

        /* PgDn */
        else if (ch == KEY_NPAGE) {
            if (mode == MODE_SEARCH) {
                results_hl += PAGE_JUMP;
                if (results_hl >= results_count) results_hl = results_count - 1;
            } else {
                page_scroll += PAGE_JUMP;
            }
        }

        /* Entrée : ouvrir */
        else if (ch == '\n' || ch == KEY_ENTER) {
            if (mode == MODE_SEARCH && results_count > 0) {
                open_url(results[results_hl].url,
                         results[results_hl].title,
                         content_win);
            } else if (mode == MODE_PAGE && links_panel_open
                       && page_links_count > 0) {
                open_url(page_links[page_links_hl].url,
                         page_links[page_links_hl].text,
                         content_win);
            }
        }

        /* Resize */
        else if (ch == KEY_RESIZE) {
            getmaxyx(stdscr, height, width);
            clear();
        }
    }

    delwin(top_win);
    delwin(addr_win);
    delwin(content_win);
    delwin(status_win);
    endwin();
    return 0;
}
