#!/usr/bin/env python3
"""
GET.py — Télécharge une page web et ses ressources (images + vidéos)
Usage: python3 GET.py <URL>

Sorties:
  datas/cache/temp.html       — HTML de la page
  datas/cache/templink.csv    — liens de la page
  datas/images/img*.{ext}     — images
  datas/videos/vid*.{ext}     — vidéos (mp4, webm, mkv...)
"""

import sys
import os
import shutil
from urllib.parse import urljoin, urlparse
from playwright.sync_api import sync_playwright
import filetype

if len(sys.argv) < 2:
    print("Usage: python3 GET.py <URL>", file=sys.stderr)
    sys.exit(1)

URL = sys.argv[1]

# ─── Config ──────────────────────────────────────────────────────────────────
BLOCKED_ADS = [
    "doubleclick.net", "google-analytics.com", "quantserve.com",
    "wikia-services.com/api/ad-info", "googlesyndication.com",
    "adnxs.com", "amazon-adsystem.com", "scorecardresearch.com",
]
# On garde: image, media (pour les intercepter nous-mêmes)
# On bloque: font, stylesheet, script (inutiles pour le rendu terminal)
BLOCKED_TYPES = {"font", "stylesheet", "script"}

IMAGE_DIR = "datas/images"
VIDEO_DIR = "datas/videos"

os.makedirs("datas/cache", exist_ok=True)
os.makedirs(IMAGE_DIR,     exist_ok=True)
os.makedirs(VIDEO_DIR,     exist_ok=True)

# ─── Helpers extension ───────────────────────────────────────────────────────
def guess_ext(content_type: str, data: bytes | None = None) -> str:
    if data:
        kind = filetype.guess(data)
        if kind:
            return "." + kind.extension
    ct = content_type.lower()
    # Images
    if "jpeg" in ct or "jpg" in ct: return ".jpg"
    if "png"  in ct: return ".png"
    if "gif"  in ct: return ".gif"
    if "webp" in ct: return ".webp"
    if "svg"  in ct: return ".svg"
    # Vidéos
    if "mp4"  in ct: return ".mp4"
    if "webm" in ct: return ".webm"
    if "ogg"  in ct: return ".ogg"
    if "mkv"  in ct: return ".mkv"
    return ".bin"

def is_video_type(content_type: str, ext: str) -> bool:
    ct = content_type.lower()
    return (any(v in ct for v in ["video/","mp4","webm","ogg","mkv"])
            or ext in (".mp4",".webm",".mkv",".ogg"))

def is_image_type(content_type: str, ext: str) -> bool:
    ct = content_type.lower()
    return (any(v in ct for v in ["image/"])
            or ext in (".jpg",".jpeg",".png",".gif",".webp",".svg"))

# ─── Intercepteur pub/tracker ────────────────────────────────────────────────
def block_ads(route):
    for blocked in BLOCKED_ADS:
        if blocked in route.request.url:
            route.abort()
            return
    if route.request.resource_type in BLOCKED_TYPES:
        route.abort()
    else:
        route.continue_()

# ─── Phase 1 : récupérer le HTML + lister les ressources ─────────────────────
image_urls = []
video_urls = []
link_urls  = []

print("[GET] Chargement de la page...", flush=True)

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page(
        user_agent=(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        ),
        locale="fr-FR",
    )
    page.route("**/*", block_ads)

    try:
        page.goto(URL, wait_until=None, timeout=30000)
        page.wait_for_timeout(4000)

        with open("datas/cache/temp.html", "w", encoding="utf-8") as f:
            f.write(page.content())

    except Exception as e:
        print(f"[GET] Erreur chargement page: {e}", file=sys.stderr)

    # ── Liens <a> ──
    for a in page.query_selector_all("a"):
        href = a.get_attribute("href")
        if href:
            link_urls.append(urljoin(URL, href))

    # ── Images <img> ──
    for img in page.query_selector_all("img"):
        src = img.get_attribute("src")
        if not src:
            srcset = img.get_attribute("srcset")
            if srcset:
                src = srcset.split(",")[0].strip().split(" ")[0]
        if src and not src.startswith("data:") and len(src) > 4:
            image_urls.append(urljoin(URL, src))

    # ── Vidéos <video> et <source> ──
    for video in page.query_selector_all("video"):
        src = video.get_attribute("src")
        if src and not src.startswith("data:"):
            video_urls.append(urljoin(URL, src))
        # sources internes
        for source in video.query_selector_all("source"):
            src2 = source.get_attribute("src")
            if src2 and not src2.startswith("data:"):
                video_urls.append(urljoin(URL, src2))

    # ── Vidéos <source> à la racine ──
    for source in page.query_selector_all("source[src]"):
        src = source.get_attribute("src")
        if src and not src.startswith("data:"):
            video_urls.append(urljoin(URL, src))

    browser.close()

print(f"[GET] {len(image_urls)} images, {len(video_urls)} vidéos, {len(link_urls)} liens",
      flush=True)

# ─── Phase 2 : téléchargement images ─────────────────────────────────────────
if os.path.exists(IMAGE_DIR):
    shutil.rmtree(IMAGE_DIR)
os.makedirs(IMAGE_DIR, exist_ok=True)

if image_urls:
    print("[GET] Téléchargement images...", flush=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            ),
            extra_http_headers={
                "Referer": URL,
                "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
            }
        )
        pg = ctx.new_page()
        nimg = 0

        for link in image_urls[:50]:   # cap à 50 images
            try:
                resp = pg.goto(link, timeout=8000)
                if not resp or resp.status >= 400:
                    continue
                data         = resp.body()
                content_type = resp.headers.get("content-type", "")
                ext          = guess_ext(content_type, data)
                if not is_image_type(content_type, ext):
                    continue
                path = os.path.join(IMAGE_DIR, f"img{nimg}{ext}")
                with open(path, "wb") as f:
                    f.write(data)
                nimg += 1
            except Exception:
                continue

        pg.close()
        browser.close()
    print(f"[GET] {nimg} images enregistrées", flush=True)

# ─── Phase 3 : téléchargement vidéos ─────────────────────────────────────────
if os.path.exists(VIDEO_DIR):
    shutil.rmtree(VIDEO_DIR)
os.makedirs(VIDEO_DIR, exist_ok=True)

if video_urls:
    print("[GET] Téléchargement vidéos...", flush=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            ),
            extra_http_headers={"Referer": URL}
        )
        pg = ctx.new_page()
        nvid = 0

        for link in video_urls[:5]:   # cap à 5 vidéos
            try:
                resp = pg.goto(link, timeout=30000)
                if not resp or resp.status >= 400:
                    continue
                data         = resp.body()
                content_type = resp.headers.get("content-type", "")
                ext          = guess_ext(content_type, data)
                if not is_video_type(content_type, ext):
                    continue
                path = os.path.join(VIDEO_DIR, f"vid{nvid}{ext}")
                with open(path, "wb") as f:
                    f.write(data)
                print(f"[GET] Vidéo: {link[:80]} → {path}", flush=True)
                nvid += 1
            except Exception as e:
                print(f"[GET] Vidéo erreur: {e}", file=sys.stderr)
                continue

        pg.close()
        browser.close()
    print(f"[GET] {nvid} vidéo(s) enregistrée(s)", flush=True)

# ─── Phase 4 : sauvegarder les liens ─────────────────────────────────────────
with open("datas/cache/templink.csv", "w", encoding="utf-8") as f:
    for link in link_urls:
        f.write(link + "\n")

print("[GET] Terminé.", flush=True)
