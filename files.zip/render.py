#!/usr/bin/env python3
"""
render.py — Convertit datas/cache/temp.html en datas/cache/page.json
Format de sortie:
{
  "lines": ["##H1 Titre", "##H2 Sous-titre", "##LK Lien", "##VD Vidéo", "##HR", "texte normal..."],
  "links": [{"text": "...", "url": "...", "line": 42}, ...]
}

Préfixes de contrôle:
  ##H1  titre h1
  ##H2  titre h2/h3
  ##H3  titre h4/h5/h6
  ##LK  lien cliquable
  ##VD  badge vidéo
  ##HR  séparateur horizontal
  (rien) texte normal
"""

import os
import sys
import json
import subprocess
import shutil
import textwrap

from bs4 import BeautifulSoup, NavigableString, Tag

HTML_FILE    = "datas/cache/temp.html"
OUTPUT_FILE  = "datas/cache/page.json"
IMAGE_DIR    = "datas/images"
VIDEO_DIR    = "datas/videos"
CHAFA_PATH   = shutil.which("chafa")

# Largeur de rendu (colonnes). On lit la vraie taille du terminal si possible.
try:
    term_width = os.get_terminal_size().columns - 2
except:
    term_width = 100
if term_width < 40:
    term_width = 40
if term_width > 200:
    term_width = 200

# ─── Rendu image via chafa ────────────────────────────────────────────────────
def render_image_chafa(path: str, width: int = 40) -> list[str]:
    """Retourne une liste de lignes ANSI générées par chafa."""
    if not CHAFA_PATH:
        return [f"  [Image: {os.path.basename(path)}]"]
    if not os.path.exists(path):
        return []
    try:
        result = subprocess.run(
            [CHAFA_PATH, f"--size={width}x20", "--colors=256",
             "--animate=off", path],
            capture_output=True, timeout=10
        )
        if result.returncode == 0:
            lines = result.stdout.decode("utf-8", errors="replace").splitlines()
            return lines if lines else [f"  [Image vide: {os.path.basename(path)}]"]
    except Exception as e:
        pass
    return [f"  [Image: {os.path.basename(path)}]"]

# ─── Parseur HTML ─────────────────────────────────────────────────────────────
BLOCK_TAGS = {
    "p","div","section","article","main","aside","header","footer",
    "nav","li","dt","dd","blockquote","pre","figure","figcaption",
    "table","tr","td","th","caption","form","fieldset","label",
    "h1","h2","h3","h4","h5","h6","hr","br","ul","ol","dl",
}
IGNORE_TAGS = {
    "script","style","noscript","meta","link","head","button",
    "input","select","option","textarea","iframe","svg","canvas",
    "template","[document]",
}

def tag_heading_level(tag_name: str) -> str | None:
    if tag_name == "h1": return "##H1 "
    if tag_name in ("h2","h3"): return "##H2 "
    if tag_name in ("h4","h5","h6"): return "##H3 "
    return None

def collect_text(node) -> str:
    """Récupère le texte plat d'un nœud."""
    if isinstance(node, NavigableString):
        return str(node)
    if node.name in IGNORE_TAGS:
        return ""
    parts = []
    for child in node.children:
        parts.append(collect_text(child))
    return " ".join(p for p in parts if p.strip())

class Renderer:
    def __init__(self, width: int):
        self.width   = width
        self.lines   = []
        self.links   = []
        self.img_idx = 0       # images déjà trouvées dans IMAGE_DIR

    def add(self, text: str):
        self.lines.append(text)

    def add_blank(self):
        if self.lines and self.lines[-1] != "":
            self.lines.append("")

    def add_wrapped(self, prefix: str, text: str):
        text = " ".join(text.split())
        if not text:
            return
        wrap_w = self.width - len(prefix)
        if wrap_w < 10:
            wrap_w = 10
        wrapped = textwrap.wrap(text, wrap_w)
        for i, line in enumerate(wrapped):
            self.lines.append((prefix if i == 0 else " " * len(prefix)) + line)

    def process(self, node):
        if isinstance(node, NavigableString):
            text = str(node).strip()
            if text:
                self.add_wrapped("  ", text)
            return

        if not isinstance(node, Tag):
            return

        name = node.name
        if not name or name in IGNORE_TAGS:
            return

        # ── Headings ──
        prefix = tag_heading_level(name)
        if prefix:
            self.add_blank()
            text = " ".join(collect_text(node).split())
            if text:
                self.add_wrapped(prefix, text)
            self.add_blank()
            return

        # ── HR ──
        if name == "hr":
            self.add("")
            self.add("##HR")
            self.add("")
            return

        # ── BR ──
        if name == "br":
            self.add("")
            return

        # ── Lien ──
        if name == "a":
            href = node.get("href", "").strip()
            text = " ".join(collect_text(node).split())
            if text and href and href not in ("#", "javascript:void(0)"):
                line_idx = len(self.lines)
                self.add(f"##LK {text}")
                self.links.append({
                    "text": text,
                    "url":  href,
                    "line": line_idx
                })
            elif text:
                self.add_wrapped("  ", text)
            return

        # ── Image ──
        if name == "img":
            # On essaie de matcher avec le fichier téléchargé (ordre d'apparition)
            img_files = sorted([
                f for f in os.listdir(IMAGE_DIR)
                if not f.endswith(".bin")
            ]) if os.path.exists(IMAGE_DIR) else []

            if self.img_idx < len(img_files):
                img_path = os.path.join(IMAGE_DIR, img_files[self.img_idx])
                self.img_idx += 1
                alt = node.get("alt", "").strip() or os.path.basename(img_path)
                self.add_blank()
                self.add(f"  ┌── Image: {alt} ──")
                chafa_lines = render_image_chafa(img_path, min(self.width - 4, 60))
                for cl in chafa_lines:
                    self.lines.append("  " + cl)
                self.add(f"  └────────────────")
                self.add_blank()
            else:
                alt = node.get("alt", "").strip()
                if alt:
                    self.add(f"  [🖼  {alt}]")
            return

        # ── Vidéo ──
        if name in ("video", "source"):
            src = node.get("src", "").strip()
            if not src and name == "video":
                src_tag = node.find("source")
                if src_tag:
                    src = src_tag.get("src", "").strip()

            # Chercher le fichier vidéo téléchargé
            vid_files = []
            if os.path.exists(VIDEO_DIR):
                vid_files = sorted([
                    f for f in os.listdir(VIDEO_DIR)
                    if f.endswith((".mp4",".webm",".mkv"))
                ])

            self.add_blank()
            if vid_files:
                vpath = os.path.join(VIDEO_DIR, vid_files[0])
                gif  = vpath.replace(".mp4", ".gif").replace(".webm", ".gif")
                mp3  = vpath.replace(".mp4", ".mp3").replace(".webm", ".mp3")
                line_idx = len(self.lines)
                self.add(f"##VD ▶  Vidéo disponible — Entrée pour lire")
                self.links.append({
                    "text": f"▶ Lire: {os.path.basename(vpath)}",
                    "url":  f"file://__video__{vpath}",
                    "line": line_idx
                })
            else:
                self.add(f"##VD ▶  Vidéo: {src[:80] if src else '(source inconnue)'}")
            self.add_blank()
            if name == "video":
                return   # pas de récursion sur <video>

        # ── Liste ──
        if name in ("ul", "ol"):
            self.add_blank()
            ordered = (name == "ol")
            counter = 1
            for child in node.children:
                if isinstance(child, Tag) and child.name == "li":
                    text = " ".join(collect_text(child).split())
                    if text:
                        bullet = f"  {counter}. " if ordered else "  • "
                        self.add_wrapped(bullet, text)
                        counter += 1
            self.add_blank()
            return

        # ── Tableau ──
        if name == "table":
            self.add_blank()
            self.add("  ┌" + "─" * (self.width - 4) + "┐")
            for row in node.find_all("tr"):
                cells = [" ".join(collect_text(c).split())
                         for c in row.find_all(["td","th"])]
                if cells:
                    row_text = " │ ".join(cells)
                    self.add_wrapped("  │ ", row_text)
            self.add("  └" + "─" * (self.width - 4) + "┘")
            self.add_blank()
            return

        # ── Blocs génériques : recurse ──
        if name in BLOCK_TAGS:
            for child in node.children:
                self.process(child)
            # Blank after block
            if name in ("p","div","section","article","blockquote","li",
                        "figure","figcaption","dd","dt"):
                self.add_blank()
            return

        # ── Inline : récupère juste le texte ──
        for child in node.children:
            self.process(child)


def main():
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

    if not os.path.exists(HTML_FILE):
        data = {"lines": ["  [Erreur: temp.html introuvable]"], "links": []}
        with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return

    with open(HTML_FILE, "r", encoding="utf-8", errors="replace") as f:
        html = f.read()

    soup = BeautifulSoup(html, "html.parser")

    # Supprime les scripts/styles inline
    for tag in soup(["script","style","noscript"]):
        tag.decompose()

    renderer = Renderer(width=term_width)

    # Titre de la page
    title_tag = soup.find("title")
    if title_tag:
        renderer.add(f"##H1 {title_tag.get_text().strip()}")
        renderer.add("##HR")
        renderer.add("")

    # Corps principal (essaie <main>, <article>, sinon <body>)
    body = (soup.find("main") or
            soup.find("article") or
            soup.find("body") or
            soup)

    renderer.process(body)

    # Dédoublonne les lignes vides
    lines = renderer.lines
    deduped = []
    prev_blank = False
    for l in lines:
        is_blank = (l.strip() == "")
        if is_blank and prev_blank:
            continue
        deduped.append(l)
        prev_blank = is_blank

    data = {"lines": deduped, "links": renderer.links}
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"[render] {len(deduped)} lignes, {len(renderer.links)} liens → {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
